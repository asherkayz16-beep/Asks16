# ASKS16 Website

A responsive standalone AI chat website with a Node.js/Express backend. The browser talks to `/api/chat` on the same server; the OpenAI API key stays on the server and is never sent to the browser.

## Deploy on Render

This project is structured so the repository root is the website root. Upload the **contents** of this folder to the top level of a GitHub repository (so `package.json` and `server.js` are visible on the repository home page).

Create a Render **Web Service** connected to that repository and use:

- Runtime: Node
- Root Directory: leave blank
- Build Command: `npm install`
- Start Command: `npm start`
- Plan: Free (for testing)

In Render → Environment, add:

- `OPENAI_API_KEY` = your secret OpenAI API key
- `OPENAI_MODEL` = `gpt-5.4-mini` (or another model enabled for your API project)

Do not upload `.env` or publish your API key. `.env.example` is only a template. Render supplies `PORT` automatically.

After deployment, open `https://YOUR-SERVICE.onrender.com/health`. A working backend should return JSON with `ok: true`. Then open the service's normal URL to use the website.

## Features

- Responsive desktop and mobile layout
- AI chat connected to the OpenAI Responses API
- Server-side API key handling
- Local browser conversation history
- New chat, recent chats, clear current chat
- Suggested prompts and loading/error states
- Basic security headers, JSON size limit and API rate limiting

## Notes

- OpenAI API usage may require separate billing/credits. Render hosting does not include OpenAI usage.
- Render's free web services may sleep when inactive, so the first request after a period of inactivity can be slow.
- This is a first working website version, not a production multi-user SaaS: it has no user accounts, synced history, payments, voice, file uploads or admin dashboard yet.
