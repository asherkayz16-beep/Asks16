import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const app = express();
const port = Number(process.env.PORT || 3000);
const model = process.env.OPENAI_MODEL || 'gpt-5.4-mini';
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: { directives: {
  defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'", "'unsafe-inline'"],
  imgSrc: ["'self'", 'data:'], connectSrc: ["'self'"], fontSrc: ["'self'", 'data:']
} } }));
app.use(express.json({ limit: '64kb' }));
app.use('/api/', rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: 'draft-7', legacyHeaders: false }));
app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'] }));

app.get('/health', (_req, res) => res.json({ ok: true, service: 'ASKS16 website backend' }));

app.post('/api/chat', async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: 'ASKS16 is not configured yet. The website owner must add the API key to the server environment.' });
    }
    const incoming = req.body?.messages;
    if (!Array.isArray(incoming) || incoming.length === 0 || incoming.length > 20) {
      return res.status(400).json({ error: 'Please send between 1 and 20 conversation messages.' });
    }
    const messages = incoming.map((item) => {
      const role = item?.role;
      const content = typeof item?.content === 'string' ? item.content.trim() : '';
      if (!['user', 'assistant'].includes(role) || !content || content.length > 12000) {
        throw new Error('A message is invalid or too long. Please shorten it and try again.');
      }
      return { role, content };
    });
    if (messages.at(-1).role !== 'user') return res.status(400).json({ error: 'The last message must be from you.' });

    const upstream = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model,
        instructions: 'You are ASKS16, a clear, capable, friendly general-purpose AI assistant. Be honest about uncertainty. Do not claim to have performed actions you have not performed. Give useful, well-structured answers. When appropriate, explain complex things step by step.',
        input: messages.map(message => ({ role: message.role, content: message.content })),
        max_output_tokens: 1400,
        store: false
      }),
      signal: AbortSignal.timeout(85_000)
    });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      console.error('OpenAI API error:', upstream.status, data?.error?.message || 'Unknown error');
      return res.status(502).json({ error: 'The AI provider could not complete that request. The site owner should check API key access, model availability and billing.' });
    }
    const reply = (data.output || []).filter(x => x.type === 'message')
      .flatMap(x => x.content || []).filter(x => x.type === 'output_text')
      .map(x => x.text).join('\n').trim();
    if (!reply) return res.status(502).json({ error: 'The AI returned an empty response. Please try again.' });
    res.json({ reply });
  } catch (error) {
    const timeout = error?.name === 'TimeoutError';
    if (!timeout) console.error('Chat route error:', error);
    res.status(timeout ? 504 : 400).json({ error: timeout ? 'The request took too long. Please try again.' : (error.message || 'Invalid request.') });
  }
});

app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.listen(port, '0.0.0.0', () => console.log(`ASKS16 website listening on port ${port}`));
