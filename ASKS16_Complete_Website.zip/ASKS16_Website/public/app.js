const form = document.getElementById('chatForm');
const promptBox = document.getElementById('prompt');
const messagesEl = document.getElementById('messages');
const welcome = document.getElementById('welcome');
const sendBtn = document.getElementById('sendBtn');
const historyEl = document.getElementById('history');
let chats = loadChats();
let activeId = null;
let busy = false;

function loadChats(){ try { const v=JSON.parse(localStorage.getItem('asks16_chats')||'[]'); return Array.isArray(v)?v:[]; } catch { return []; } }
function saveChats(){ try { localStorage.setItem('asks16_chats',JSON.stringify(chats.slice(0,30))); } catch {} }
function makeId(){ return `${Date.now()}-${Math.random().toString(36).slice(2,8)}`; }
function activeChat(){ return chats.find(c=>c.id===activeId); }
function escapeText(s){ return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function renderHistory(){
  historyEl.innerHTML='';
  if(!chats.length){historyEl.innerHTML='<div class="history-empty">Your conversations will appear here.</div>';return;}
  chats.slice(0,15).forEach(chat=>{const b=document.createElement('button');b.className='history-item';b.textContent=chat.title||'New conversation';b.title=b.textContent;b.onclick=()=>openChat(chat.id);historyEl.appendChild(b);});
}
function renderMessages(){
  const chat=activeChat(); messagesEl.innerHTML='';
  if(!chat||!chat.messages.length){welcome.style.display='block';messagesEl.classList.remove('visible');return;}
  welcome.style.display='none';messagesEl.classList.add('visible');
  chat.messages.forEach(m=>addMessage(m.role,m.content));
  messagesEl.scrollTop=messagesEl.scrollHeight;
}
function addMessage(role,content,extra=''){
  const row=document.createElement('div');row.className=`message ${role==='user'?'user':'assistant'}`;
  const avatar=document.createElement('div');avatar.className='msg-avatar';avatar.textContent=role==='user'?'Y':'A16';
  const bubble=document.createElement('div');bubble.className=`bubble ${extra}`;bubble.textContent=content;
  row.append(avatar,bubble);messagesEl.appendChild(row);messagesEl.scrollTop=messagesEl.scrollHeight;return bubble;
}
function newChat(){activeId=null;renderMessages();promptBox.focus();}
function openChat(id){activeId=id;renderMessages();closeSidebar();}
function closeSidebar(){document.getElementById('sidebar').classList.remove('open');document.getElementById('scrim').classList.remove('show');}
function setBusy(v){busy=v;sendBtn.disabled=v;sendBtn.innerHTML=v?'…':'<span>↑</span>';}
async function sendMessage(text){
  const content=text.trim();if(!content||busy)return;
  if(!activeChat()){activeId=makeId();chats.unshift({id:activeId,title:content.slice(0,42),messages:[]});}
  const chat=activeChat();chat.messages.push({role:'user',content});saveChats();renderHistory();
  if(welcome.style.display!=='none'){welcome.style.display='none';messagesEl.classList.add('visible');}
  addMessage('user',content);promptBox.value='';resizeInput();setBusy(true);
  const typing=addMessage('assistant','ASKS16 is thinking','typing');
  try{
    const response=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({messages:chat.messages.slice(-20)})});
    const data=await response.json().catch(()=>({}));
    if(!response.ok)throw new Error(data.error||`Request failed (${response.status}).`);
    typing.textContent=data.reply||'I could not produce a response. Please try again.';typing.classList.remove('typing');
    chat.messages.push({role:'assistant',content:typing.textContent});saveChats();
  }catch(error){typing.textContent=error.message||'Could not connect to ASKS16. Check your internet connection and try again.';typing.classList.remove('typing');typing.classList.add('error');}
  finally{setBusy(false);promptBox.focus();}
}
function resizeInput(){promptBox.style.height='auto';promptBox.style.height=Math.min(promptBox.scrollHeight,170)+'px';}
form.addEventListener('submit',e=>{e.preventDefault();sendMessage(promptBox.value);});
promptBox.addEventListener('input',resizeInput);
promptBox.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();form.requestSubmit();}});
document.getElementById('newChat').addEventListener('click',newChat);
document.getElementById('clearBtn').addEventListener('click',()=>{if(!activeId)return;chats=chats.filter(c=>c.id!==activeId);activeId=null;saveChats();renderHistory();renderMessages();});
document.querySelectorAll('.suggestion').forEach(b=>b.addEventListener('click',()=>sendMessage(b.dataset.prompt)));
document.getElementById('exploreBtn').addEventListener('click',()=>{welcome.style.display='block';messagesEl.classList.remove('visible');closeSidebar();});
document.getElementById('menuBtn').addEventListener('click',()=>{document.getElementById('sidebar').classList.add('open');document.getElementById('scrim').classList.add('show');});
document.getElementById('closeSidebar').addEventListener('click',closeSidebar);
document.getElementById('scrim').addEventListener('click',closeSidebar);
renderHistory();renderMessages();
