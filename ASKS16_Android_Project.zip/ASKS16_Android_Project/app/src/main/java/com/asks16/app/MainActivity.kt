package com.asks16.app

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("asks16", MODE_PRIVATE) }
    private val worker = Executors.newSingleThreadExecutor()
    private val history = mutableListOf<Pair<String, String>>()
    private lateinit var messages: LinearLayout
    private lateinit var scroller: ScrollView
    private lateinit var composer: EditText
    private lateinit var status: TextView
    private lateinit var sendButton: TextView
    private var busy = false

    private val bg = Color.rgb(9, 11, 18)
    private val panel = Color.rgb(19, 23, 34)
    private val purple = Color.rgb(167, 139, 250)
    private val white = Color.rgb(244, 245, 250)
    private val muted = Color.rgb(150, 157, 176)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        loadHistory()
        buildScreen()
        if (history.isEmpty()) {
            addMessage("assistant", "Hello! I'm ASKS16, your AI assistant.\n\nAsk me to explain something, write, plan, translate, brainstorm or help solve a problem.\n\nTo connect real AI, add your deployed HTTPS backend URL in Settings (⚙).")
        } else {
            history.forEach { addBubble(it.first, it.second) }
        }
        updateConnectionStatus()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(16), dp(10), dp(16), dp(10))
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, dp(12))
        }
        val brandColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val brand = TextView(this).apply {
            text = "✦  ASKS16"
            textSize = 23f
            setTextColor(white)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        status = TextView(this).apply { textSize = 11f; setTextColor(muted); text = "AI assistant · Not connected" }
        brandColumn.addView(brand)
        brandColumn.addView(status)
        top.addView(brandColumn, LinearLayout.LayoutParams(0, -2, 1f))
        val settings = TextView(this).apply {
            text = "⚙"
            textSize = 23f
            gravity = Gravity.CENTER
            setTextColor(white)
            background = rounded(panel, 16)
            setOnClickListener { showSettings() }
        }
        top.addView(settings, LinearLayout.LayoutParams(dp(46), dp(46)))
        root.addView(top)

        scroller = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setPadding(0, dp(4), 0, dp(8))
        }
        messages = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroller.addView(messages, ScrollView.LayoutParams(-1, -2))
        root.addView(scroller, LinearLayout.LayoutParams(-1, 0, 1f))

        val composerPanel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
            background = rounded(panel, 22)
            setPadding(dp(10), dp(8), dp(8), dp(8))
        }
        composer = EditText(this).apply {
            hint = "Message ASKS16…"
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 16f
            setPadding(dp(10), dp(8), dp(8), dp(8))
            background = null
            minLines = 1
            maxLines = 5
            imeOptions = EditorInfo.IME_ACTION_SEND
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_SEND) { sendMessage(); true } else false
            }
        }
        composerPanel.addView(composer, LinearLayout.LayoutParams(0, -2, 1f))
        sendButton = TextView(this).apply {
            text = "➤"
            textSize = 21f
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK)
            background = rounded(purple, 18)
            setOnClickListener { sendMessage() }
        }
        composerPanel.addView(sendButton, LinearLayout.LayoutParams(dp(48), dp(48)))
        root.addView(composerPanel)
        val foot = TextView(this).apply {
            text = "ASKS16 can make mistakes. Check important information."
            textSize = 10f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        }
        root.addView(foot)
        setContentView(root)
    }

    private fun sendMessage() {
        if (busy) return
        val prompt = composer.text.toString().trim()
        if (prompt.isEmpty()) return
        composer.setText("")
        hideKeyboard()
        addMessage("user", prompt)
        val endpoint = prefs.getString("backend_url", "")?.trim().orEmpty().trimEnd('/')
        if (endpoint.isBlank()) {
            addMessage("assistant", "Your message is saved, but ASKS16 is not connected to an AI server yet. Tap ⚙ and enter your deployed HTTPS backend URL to enable real AI replies.")
            return
        }
        if (!endpoint.startsWith("https://")) {
            addMessage("assistant", "For security, ASKS16 only accepts an HTTPS backend URL. Update it in Settings.")
            return
        }
        busy = true
        setBusy(true)
        val loading = addBubble("assistant", "Thinking…")
        worker.execute {
            try {
                val answer = requestAssistant(endpoint)
                runOnUiThread {
                    messages.removeView(loading)
                    addMessage("assistant", answer)
                    busy = false
                    setBusy(false)
                    updateConnectionStatus(true)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    messages.removeView(loading)
                    addMessage("assistant", "I couldn't reach the AI service. Check the backend URL and server status, then try again.\n\nDetails: ${e.message ?: "Network error"}")
                    busy = false
                    setBusy(false)
                    updateConnectionStatus(false)
                }
            }
        }
    }

    private fun requestAssistant(endpoint: String): String {
        val url = URL("$endpoint/api/chat")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 90000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
        }
        try {
            val payload = JSONObject().put("messages", JSONArray().also { arr ->
                history.takeLast(20).forEach { (role, content) -> arr.put(JSONObject().put("role", role).put("content", content)) }
            })
            connection.outputStream.use { it.write(payload.toString().toByteArray(StandardCharsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IllegalStateException("Server returned HTTP $code: ${body.take(300)}")
            val json = JSONObject(body)
            return json.optString("reply").takeIf { it.isNotBlank() }
                ?: throw IllegalStateException("The server returned an empty reply")
        } finally {
            connection.disconnect()
        }
    }

    private fun addMessage(role: String, content: String) {
        history.add(role to content)
        if (history.size > 40) history.removeAt(0)
        saveHistory()
        addBubble(role, content)
    }

    private fun addBubble(role: String, content: String): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = if (role == "user") Gravity.END else Gravity.START
            setPadding(0, dp(5), 0, dp(5))
        }
        val bubble = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(if (role == "user") Color.rgb(49, 43, 79) else panel, 18)
            setPadding(dp(14), dp(11), dp(14), dp(11))
        }
        val label = TextView(this).apply {
            text = if (role == "user") "YOU" else "ASKS16"
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(if (role == "user") Color.rgb(205, 190, 255) else purple)
        }
        val body = TextView(this).apply {
            text = content
            textSize = 15f
            setTextColor(white)
            setPadding(0, dp(5), 0, 0)
            setTextIsSelectable(true)
            setLineSpacing(dp(2).toFloat(), 1f)
        }
        bubble.addView(label)
        bubble.addView(body)
        row.addView(bubble, LinearLayout.LayoutParams((resources.displayMetrics.widthPixels * 0.82f).toInt(), -2))
        messages.addView(row)
        scroller.post { scroller.fullScroll(View.FOCUS_DOWN) }
        return row
    }

    private fun showSettings() {
        val field = EditText(this).apply {
            hint = "https://your-backend.example.com"
            setText(prefs.getString("backend_url", ""))
            setTextColor(white)
            setHintTextColor(muted)
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        val wrap = LinearLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(field) }
        AlertDialog.Builder(this)
            .setTitle("ASKS16 connection")
            .setMessage("Enter the HTTPS address of your deployed ASKS16 backend. Do not paste your OpenAI API key here.")
            .setView(wrap)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit().putString("backend_url", field.text.toString().trim().trimEnd('/')).apply()
                updateConnectionStatus()
                Toast.makeText(this, "Backend address saved", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("Clear chat") { _, _ ->
                history.clear(); saveHistory(); messages.removeAllViews()
                addMessage("assistant", "Chat cleared. I'm ready for a new conversation.")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun updateConnectionStatus(connected: Boolean? = null) {
        val configured = !prefs.getString("backend_url", "").isNullOrBlank()
        status.text = when (connected) {
            true -> "● Connected · AI ready"
            false -> "● Connection problem"
            else -> if (configured) "● Backend configured · Ready to test" else "● Not connected · Set up backend"
        }
        status.setTextColor(if (connected == true) Color.rgb(111, 220, 160) else muted)
    }

    private fun setBusy(value: Boolean) {
        sendButton.text = if (value) "…" else "➤"
        sendButton.alpha = if (value) 0.55f else 1f
    }

    private fun saveHistory() {
        val array = JSONArray()
        history.forEach { (role, text) -> array.put(JSONObject().put("role", role).put("content", text)) }
        prefs.edit().putString("history", array.toString()).apply()
    }

    private fun loadHistory() {
        try {
            val array = JSONArray(prefs.getString("history", "[]"))
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                history.add(item.getString("role") to item.getString("content"))
            }
        } catch (_: Exception) { history.clear() }
    }

    private fun hideKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(composer.windowToken, 0)
        composer.clearFocus()
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        worker.shutdown()
        super.onDestroy()
    }
}
