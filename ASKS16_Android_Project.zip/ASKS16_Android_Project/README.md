# ASKS16 Android + AI Backend

Version 2.0.0 — rebuilt from the supplied MyAI Android project.

## What is included

- Native Kotlin Android app (no third-party Android libraries required).
- Repaired the original invalid Kotlin string and replaced the demo reply logic.
- Dark ASKS16 chat interface, multiline composer, send action and connection status.
- Local conversation history stored on the device.
- HTTPS-only backend connection configured from the app's Settings button.
- Node.js backend that calls the OpenAI Responses API.
- Server-side API key handling, request validation, rate limiting, security headers and health endpoint.

## Important status

This is a source project, not a prebuilt APK. The live AI connection will work only after you deploy the backend, set a valid OpenAI API key on the server, and enter the backend's HTTPS URL in the Android app. The API key must never be pasted into Android Studio source code or the app's Settings.

## Part A — deploy the backend

Requirements: Node.js 20 or newer and a hosting provider that supports Node.js applications and environment variables.

1. Upload the entire `backend` folder to a Node.js host (or deploy it from a Git repository).
2. In the host's environment-variable settings, add:
   - `OPENAI_API_KEY` = your OpenAI API key
   - `OPENAI_MODEL` = `gpt-5.4-mini` (or another model enabled for your API project)
   - `PORT` = use the host-provided port if the host requires it; otherwise omit it.
3. Install dependencies with `npm install`.
4. Start the service with `npm start`.
5. Open `https://YOUR-HOST/health`. It should return JSON similar to `{"ok":true,"service":"ASKS16 backend"}`.
6. Keep the backend on HTTPS. Do not expose the API key in client-side code, logs, screenshots or chat messages.

For local testing only, copy `.env.example` to `.env`, fill in the key, then run `npm install` and `npm start`. Do not commit `.env` to Git. The Android app intentionally rejects plain HTTP addresses, including local emulator URLs.

## Part B — open the Android project

1. Extract the ZIP.
2. Open the extracted `ASKS16_Android_Project` folder in Android Studio.
3. Allow Android Studio to sync Gradle. Use JDK 17 or newer and Android SDK Platform 35.
4. Connect an Android phone with USB debugging enabled, or create an emulator.
5. Press Run. Android Studio will build and install the app.
6. In ASKS16, tap the gear icon and enter the backend base URL, for example `https://your-service.example.com` (do not add `/api/chat`).
7. Send a test message.

To create an APK in Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**. The debug APK is normally found under `app/build/outputs/apk/debug/`.

## API contract

`POST /api/chat`

Request:

```json
{
  "messages": [
    { "role": "user", "content": "Hello" }
  ]
}
```

Success:

```json
{ "reply": "Hello! How can I help?" }
```

Health check: `GET /health`.

## Current scope and next upgrades

The current rebuild provides text chat and locally saved conversation history. It does not yet include accounts, cloud-synced history, voice, image/file uploads, web search, subscriptions, or an offline language model. Those should be added in separate tested stages.

## Security notes

- The OpenAI key stays on the backend.
- The Android client only communicates with HTTPS endpoints.
- Server request size and message count are bounded; requests are rate-limited.
- Add authentication and per-user quotas before public launch. The included rate limit is a basic shared IP limit, not a complete abuse-prevention system.
- Review your hosting provider's data retention and logs before handling sensitive conversations.
