import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';

const app = express();
const port = Number(process.env.PORT || 3000);
const model = process.env.OPENAI_MODEL || 'gpt-5.4-mini';

app.disable('x-powered-by');
app.use(helmet());
app.use(express.json({ limit: '64kb' }));
app.use(rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: 'draft-7', legacyHeaders: false }));

const allowedOrigins = (process.env.ALLOWED_ORIGINS || '').split(',').map(x => x.trim()).filter(Boolean);
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin && allowedOrigins.includes(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.setHeader('Access-Control-Allow-Methods', 'POST, GET, OPTIONS');
  }
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

app.get('/health', (_req, res) => res.json({ ok: true, service: 'ASKS16 backend' }));

app.post('/api/chat', async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: 'AI service is not configured on the server.' });
    }

    const incoming = req.body?.messages;
    if (!Array.isArray(incoming) || incoming.length === 0 || incoming.length > 20) {
      return res.status(400).json({ error: 'messages must be a non-empty array containing at most 20 messages.' });
    }

    const messages = incoming.map((item) => {
      const role = item?.role;
      const content = typeof item?.content === 'string' ? item.content.trim() : '';
      if (!['user', 'assistant'].includes(role) || !content || content.length > 12000) {
        throw new Error('Each message must have role user/assistant and content up to 12,000 characters.');
      }
      return { role, content };
    });

    if (messages[messages.length - 1].role !== 'user') {
      return res.status(400).json({ error: 'The final message must be from the user.' });
    }

    const upstream = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model,
        instructions: 'You are ASKS16, a clear, capable, friendly general-purpose AI assistant. Be honest about uncertainty. Do not claim to have performed actions you have not performed. Use concise, useful answers and format longer answers clearly.',
        input: messages.map(message => ({ role: message.role, content: message.content })),
        max_output_tokens: 1200,
        store: false
      }),
      signal: AbortSignal.timeout(85_000)
    });

    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      console.error('OpenAI API error:', upstream.status, data?.error?.message || 'Unknown error');
      return res.status(502).json({ error: 'The AI provider could not complete the request. Check the server API key, project access, model and billing.' });
    }

    const reply = (data.output || [])
      .filter(item => item.type === 'message')
      .flatMap(item => item.content || [])
      .filter(item => item.type === 'output_text')
      .map(item => item.text)
      .join('\n')
      .trim();

    if (!reply) return res.status(502).json({ error: 'The AI provider returned no text. Please try again.' });
    return res.json({ reply });
  } catch (error) {
    const message = error?.name === 'TimeoutError' ? 'The AI request timed out. Please try again.' : error.message;
    if (error?.name !== 'TimeoutError') console.error('Chat route error:', error);
    return res.status(400).json({ error: message || 'Invalid request.' });
  }
});

app.use((error, _req, res, _next) => {
  console.error('Unhandled server error:', error);
  res.status(500).json({ error: 'Unexpected server error.' });
});

app.listen(port, () => console.log(`ASKS16 backend listening on port ${port}`));
